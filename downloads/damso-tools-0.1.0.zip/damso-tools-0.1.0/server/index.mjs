// server/index.mjs
import fs7 from "node:fs/promises";
import path7 from "node:path";
import { fileURLToPath } from "node:url";

// shared/contracts/index.mjs
var PACKAGE_VERSION = "0.1.0";
var PROTOCOL_VERSION = 1;
var API_ROOT = "/api/plugins/st-ko-tools/v1";
var HOST_VERSIONS = ["1.18.0", "1.19.0"];
var TERMINAL = /* @__PURE__ */ new Set(["saved", "conflict", "canceled", "failed", "interrupted"]);
var CONFIG_DEFAULTS = Object.freeze({
  settingsAccelerationEnabled: true,
  lazyThemeLoadingEnabled: true,
  extensionManifestBundleEnabled: true,
  characterListAccelerationEnabled: true,
  recentChatListAccelerationEnabled: true,
  tokenizerBulkCountEnabled: true,
  chatKeyboardScanReductionEnabled: false,
  progressiveChatLoadingEnabled: false,
  backupAutoCleanupEnabled: true,
  backupKeepCount: 200
});
var ApiError = class extends Error {
  constructor(status, code, message, details = {}) {
    super(message);
    Object.assign(this, { status, code, details });
  }
};
function requireValue(condition, message = "\uC694\uCCAD \uD615\uC2DD\uC774 \uC62C\uBC14\uB974\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.") {
  if (!condition) throw new ApiError(400, "INVALID_REQUEST", message);
}

// server/storage/documents.mjs
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
var queues = /* @__PURE__ */ new Map();
async function serialized(key, action) {
  const previous = queues.get(key) || Promise.resolve();
  const current = previous.catch(() => {
  }).then(action);
  queues.set(key, current);
  try {
    return await current;
  } finally {
    if (queues.get(key) === current) queues.delete(key);
  }
}
async function atomicJson(file, data) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 448 });
  const temp = `${file}.${randomUUID()}.tmp`;
  let handle;
  try {
    handle = await fs.open(temp, "wx", 384);
    await handle.writeFile(JSON.stringify(data));
    await handle.sync();
    await handle.close();
    handle = null;
    await fs.rename(temp, file);
    const dir = await fs.open(path.dirname(file), "r");
    try {
      await dir.sync();
    } finally {
      await dir.close();
    }
  } finally {
    await handle?.close();
    await fs.rm(temp, { force: true });
  }
}
async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return structuredClone(fallback);
    throw error;
  }
}
async function userStore(user) {
  if (!user?.directories?.root || !user?.profile?.handle) throw new ApiError(401, "AUTH_REQUIRED", "\uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.");
  const root = await fs.realpath(user.directories.root);
  const store = path.join(root, "st-ko-tools");
  await fs.mkdir(store, { recursive: true, mode: 448 });
  if (await fs.realpath(store) !== store) throw new ApiError(400, "INVALID_PATH", "\uC800\uC7A5 \uACBD\uB85C\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694.");
  return store;
}
async function readDocument(user, name, defaults2) {
  const file = path.join(await userStore(user), `${name}.json`);
  const doc = await readJson(file, { schemaVersion: 1, revision: 0, ...defaults2 });
  if (doc.schemaVersion !== 1 || !Number.isSafeInteger(doc.revision)) throw new ApiError(503, "INVALID_STORAGE", "\uC800\uC7A5\uC18C \uD615\uC2DD\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.");
  return doc;
}
async function changeDocument(user, name, defaults2, expectedRevision, transform) {
  const file = path.join(await userStore(user), `${name}.json`);
  return serialized(file, async () => {
    const current = await readDocument(user, name, defaults2);
    requireValue(Number.isSafeInteger(expectedRevision), "expectedRevision\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.");
    if (current.revision !== expectedRevision) throw new ApiError(409, "REVISION_CONFLICT", "\uB2E4\uB978 \uCC3D\uC5D0\uC11C \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uBD88\uB7EC\uC640 \uC8FC\uC138\uC694.", { revision: current.revision });
    const next = { ...await transform(structuredClone(current)), schemaVersion: 1, revision: current.revision + 1 };
    await atomicJson(file, next);
    return next;
  });
}
async function safeFile(root, relative) {
  requireValue(typeof relative === "string" && relative.length > 0 && !relative.includes("\0"));
  const base = await fs.realpath(root);
  const file = path.resolve(base, relative);
  requireValue(file.startsWith(base + path.sep), "\uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC740 \uD30C\uC77C \uACBD\uB85C\uC785\uB2C8\uB2E4.");
  let parent = file;
  while (parent !== base) {
    try {
      const resolved = await fs.realpath(parent);
      requireValue(resolved === base || resolved.startsWith(base + path.sep), "\uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC740 \uD30C\uC77C \uACBD\uB85C\uC785\uB2C8\uB2E4.");
      break;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      parent = path.dirname(parent);
    }
  }
  return file;
}

// server/services/library.mjs
var defaults = { items: [], groups: [] };
var getLibrary = (user) => readDocument(user, "prompt-library", defaults);
function putLibrary(user, body) {
  requireValue(Array.isArray(body.items) && Array.isArray(body.groups));
  for (const entries of [body.items, body.groups]) {
    requireValue(entries.length <= 1e4);
    const ids = entries.map((x) => x?.id);
    requireValue(ids.every((x) => typeof x === "string" && x) && new Set(ids).size === ids.length, "\uD56D\uBAA9 ID\uB294 \uBE44\uC5B4 \uC788\uAC70\uB098 \uC911\uBCF5\uB420 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
  }
  return changeDocument(user, "prompt-library", defaults, body.expectedRevision, (current) => ({ ...current, items: body.items, groups: body.groups }));
}

// server/services/backups.mjs
import path3 from "node:path";
import fs3 from "node:fs/promises";
import { randomUUID as randomUUID2 } from "node:crypto";

// server/services/config.mjs
import fs2 from "node:fs/promises";
import path2 from "node:path";
var legacyKeys = { settingsAccelerationEnabled: "baibaokuSettingsAccelerationEnabled", lazyThemeLoadingEnabled: "baibaokuLazyThemeLoadingEnabled", extensionManifestBundleEnabled: "extensionManifestBundleEnabled", characterListAccelerationEnabled: "fastCharacterListEnabled", recentChatListAccelerationEnabled: "recentChatListAccelerationEnabled", tokenizerBulkCountEnabled: "tokenizerBulkCountEnabled", chatKeyboardScanReductionEnabled: "chatKeyboardScanReductionEnabled", backupAutoCleanupEnabled: "presetBackupAutoCleanupEnabled", backupKeepCount: "presetBackupKeepCount" };
async function uiEnabled(user) {
  try {
    await fs2.access(path2.join(user.directories.extensions, "damso-tools/manifest.json"));
    const settings = JSON.parse(await fs2.readFile(path2.join(user.directories.root, "settings.json"), "utf8"));
    return !settings.extension_settings?.disabledExtensions?.includes("third-party/damso-tools");
  } catch {
    return false;
  }
}
async function getConfig(user) {
  const file = path2.join(await userStore(user), "config.json");
  return serialized(file, async () => {
    const current = await readDocument(user, "config", CONFIG_DEFAULTS);
    if (current.revision !== 0) return { ...CONFIG_DEFAULTS, ...current };
    let saved = {};
    try {
      saved = JSON.parse(await fs2.readFile(path2.join(user.directories.root, "settings.json"), "utf8")).extension_settings?.baiBaiToolkit || {};
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    for (const [key, legacy] of Object.entries(legacyKeys)) if (typeof saved[legacy] === typeof CONFIG_DEFAULTS[key]) current[key] = saved[legacy];
    if (!Number.isSafeInteger(current.backupKeepCount) || current.backupKeepCount < 1 || current.backupKeepCount > 1e5) current.backupKeepCount = 200;
    if (!current.settingsAccelerationEnabled) current.lazyThemeLoadingEnabled = false;
    current.progressiveChatLoadingEnabled = false;
    current.revision = 1;
    await atomicJson(file, current);
    return current;
  });
}

// server/services/backups.mjs
var Backups = class {
  async directory(user) {
    const dir = path3.join(await userStore(user), "preset-backups");
    await fs3.mkdir(dir, { recursive: true, mode: 448 });
    return dir;
  }
  async file(user, id) {
    requireValue(typeof id === "string" && /^[a-f0-9-]{36}\.json$/.test(id));
    return path3.join(await this.directory(user), id);
  }
  async records(user) {
    const dir = await this.directory(user);
    const files = (await fs3.readdir(dir)).filter((x) => x.endsWith(".json"));
    const records = await Promise.all(files.map(async (f) => {
      const doc = await readJson(path3.join(dir, f));
      if (doc?.schemaVersion !== 1 || doc.fileName !== f || typeof doc.note !== "string" || !Number.isFinite(doc.createdAtMs)) throw new ApiError(503, "INVALID_BACKUP", "\uBC31\uC5C5 \uBA54\uD0C0\uB370\uC774\uD130\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694. \uC815\uB9AC\uB97C \uC911\uB2E8\uD588\uC2B5\uB2C8\uB2E4.");
      return doc;
    }));
    return records.sort((a, b) => b.createdAtMs - a.createdAtMs || b.fileName.localeCompare(a.fileName));
  }
  async list(user) {
    return { items: (await this.records(user)).map(({ body, ...meta }) => meta) };
  }
  async get(user, id) {
    const doc = await readJson(await this.file(user, id), null);
    if (!doc) throw new ApiError(404, "NOT_FOUND", "\uBC31\uC5C5\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    return doc;
  }
  async create(user, body) {
    requireValue(body?.preset && typeof body.preset === "object" && !Array.isArray(body.preset) && typeof body.name === "string");
    return serialized(await this.directory(user), async () => {
      const fileName = `${randomUUID2()}.json`;
      const createdAtMs = Date.now();
      const doc = { schemaVersion: 1, revision: 1, fileName, name: body.name, showName: body.name, note: "", createdAtMs, createdAt: new Date(createdAtMs).toISOString(), body };
      await atomicJson(await this.file(user, fileName), doc);
      const config = await getConfig(user);
      if (config.backupAutoCleanupEnabled !== false) await this.prune(user, config.backupKeepCount ?? 200);
      return doc;
    });
  }
  async prune(user, count) {
    requireValue(Number.isSafeInteger(count) && count >= 1);
    const ordinary = (await this.records(user)).filter((x) => !x.note.trim());
    for (const record of ordinary.slice(count)) await fs3.unlink(await this.file(user, record.fileName));
  }
  async mutate(user, id, change, expectedRevision) {
    return serialized(await this.directory(user), async () => {
      const record = await this.get(user, id);
      if (expectedRevision !== void 0 && expectedRevision !== record.revision) throw new ApiError(409, "REVISION_CONFLICT", "\uBC31\uC5C5 \uC815\uBCF4\uAC00 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
      if (change === "delete") {
        await fs3.unlink(await this.file(user, id));
        return { deleted: true, fileName: id };
      }
      const updated = { ...record, ...change, revision: record.revision + 1 };
      await atomicJson(await this.file(user, id), updated);
      return updated;
    });
  }
};

// server/services/cache.mjs
import fs4 from "node:fs/promises";
import path4 from "node:path";
import { createHash } from "node:crypto";
async function fingerprint(root, hash) {
  try {
    const rootStat = await fs4.stat(root);
    if (rootStat.isFile()) {
      hash.update(`${root}:${rootStat.size}:${rootStat.mtimeMs}:${rootStat.ctimeMs}`);
      return;
    }
    const entries = await fs4.readdir(root, { withFileTypes: true });
    for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (entry.name.startsWith(".") || entry.isSymbolicLink()) continue;
      const file = path4.join(root, entry.name);
      if (entry.isDirectory()) await fingerprint(file, hash);
      else {
        const s = await fs4.stat(file);
        hash.update(`${file}:${s.size}:${s.mtimeMs}:${s.ctimeMs}`);
      }
    }
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    hash.update("missing");
  }
}
var FileCache = class {
  entries = /* @__PURE__ */ new Map();
  async get(user, key, directories, compute) {
    const hash = createHash("sha256");
    for (const dir of directories) await fingerprint(dir, hash);
    const revision = hash.digest("hex");
    const id = `${user.directories.root}:${key}`;
    const found = this.entries.get(id);
    if (found?.revision === revision) return structuredClone(found.value);
    const value = await compute();
    this.entries.set(id, { revision, value: structuredClone(value) });
    if (this.entries.size > 100) this.entries.delete(this.entries.keys().next().value);
    return value;
  }
  clear(user) {
    for (const key of this.entries.keys()) if (key.startsWith(user.directories.root + ":")) this.entries.delete(key);
  }
};

// server/jobs/manager.mjs
import fs5 from "node:fs/promises";
import path5 from "node:path";
import { randomUUID as randomUUID3 } from "node:crypto";
var JobManager = class {
  constructor(host) {
    this.host = host;
    this.active = /* @__PURE__ */ new Map();
    this.users = /* @__PURE__ */ new Map();
    this.stopping = false;
  }
  async state(user) {
    const root = await userStore(user);
    if (!this.users.has(root)) this.users.set(root, this.restore(user, root));
    return this.users.get(root);
  }
  async restore(user, root) {
    const file = path5.join(root, "jobs.json");
    const doc = await readJson(file, { schemaVersion: 1, revision: 0, jobs: [] });
    if (doc.schemaVersion !== 1 || !Array.isArray(doc.jobs)) throw new ApiError(503, "INVALID_JOBS", "\uC791\uC5C5 \uAE30\uB85D\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.");
    const state = { file, doc, user };
    for (const job of doc.jobs.filter((j) => !TERMINAL.has(j.status))) {
      await this.host.coordinator.withChatWrite(user, async () => {
        const target = this.host.coordinator.chatPath(user, job.target);
        const chat = await this.readChat(target);
        const saved = chat.some((m) => m.extra?.damsoJobId === job.id);
        job.status = saved ? "saved" : "interrupted";
        if (saved) job.savedRevision = this.host.coordinator.fileRevision(target);
      });
    }
    await this.persist(state);
    return state;
  }
  async persist(state) {
    state.doc.revision++;
    await atomicJson(state.file, state.doc);
  }
  async readChat(file) {
    try {
      return (await fs5.readFile(file, "utf8")).split("\n").filter((x) => x.trim()).map((x) => JSON.parse(x));
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
  }
  async list(user) {
    return (await this.state(user)).doc.jobs.map((j) => structuredClone(j));
  }
  async get(user, id) {
    const job = (await this.state(user)).doc.jobs.find((j) => j.id === id || j.clientRequestId === id);
    if (!job) throw new ApiError(404, "NOT_FOUND", "\uC791\uC5C5\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    return structuredClone(job);
  }
  async submit(user, body) {
    requireValue(!this.stopping, "\uC11C\uBC84\uB97C \uC885\uB8CC\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4.");
    requireValue(typeof body.clientRequestId === "string" && body.clientRequestId.length <= 160 && body.clientRequestId.length >= 8);
    const state = await this.state(user);
    return this.host.coordinator.withChatWrite(user, () => serialized(state.file, async () => {
      const existing = state.doc.jobs.find((j) => j.clientRequestId === body.clientRequestId);
      if (existing) return structuredClone(existing);
      const generate = structuredClone(body.generate);
      requireValue(generate && ["openai", "custom"].includes(generate.chat_completion_source), "\uBC31\uADF8\uB77C\uC6B4\uB4DC \uC0DD\uC131\uC740 OpenAI\xB7Custom \uC18C\uC2A4\uB97C \uC9C0\uC6D0\uD569\uB2C8\uB2E4.");
      requireValue(Number(generate.n ?? 1) === 1 && ["normal", "regenerate"].includes(body.target?.type));
      requireValue(Array.isArray(generate.messages) && typeof body.expectedRevision === "string");
      if (generate.tools?.length) {
        const tool = generate.tools[0];
        requireValue(generate.tools.length === 1 && tool.type === "function" && /^emit_complete_response(?:_[a-zA-Z0-9]+)?$/.test(tool?.function?.name) && tool.function.parameters?.type === "object" && tool.function.parameters?.properties?.content?.type === "string" && tool.function.parameters.required?.includes("content"), "\uC77C\uBC18 \uB3C4\uAD6C \uD638\uCD9C\uC740 \uAE30\uBCF8 \uC0DD\uC131\uC73C\uB85C \uC2E4\uD589\uD574 \uC8FC\uC138\uC694.");
      }
      delete generate.__baibai_generation_id;
      const target = { avatar_url: body.target.avatar_url, file_name: body.target.file_name, type: body.target.type, ch_name: String(body.target.ch_name || ""), chatId: String(body.target.chatId || "") };
      {
        const file = this.host.coordinator.chatPath(user, target);
        if (this.host.coordinator.fileRevision(file) !== body.expectedRevision) throw new ApiError(409, "REVISION_CONFLICT", "\uCC44\uD305\uC774 \uBCC0\uACBD\uB418\uC5B4 \uC0DD\uC131\uC744 \uC2DC\uC791\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
        const chat = await this.readChat(file);
        requireValue(chat.length >= 2, "\uBA3C\uC800 \uCC44\uD305\uC744 \uC800\uC7A5\uD574 \uC8FC\uC138\uC694.");
      }
      const job = {
        id: randomUUID3(),
        clientRequestId: body.clientRequestId,
        runId: body.runId || body.clientRequestId,
        attempt: body.attempt || 0,
        target,
        expectedRevision: body.expectedRevision,
        status: "accepted",
        createdAt: Date.now(),
        toolName: generate.tools?.[0]?.function?.name || ""
      };
      state.doc.jobs.push(job);
      await this.persist(state);
      const controller = new AbortController();
      const active = { controller, promise: null };
      this.active.set(job.id, active);
      active.promise = this.run(state, job, generate, controller.signal).finally(() => this.active.delete(job.id));
      return structuredClone(job);
    }));
  }
  async update(state, job, changes) {
    return serialized(state.file, async () => {
      Object.assign(job, changes, { updatedAt: Date.now() });
      await this.persist(state);
    });
  }
  async run(state, job, generate, signal) {
    try {
      await this.update(state, job, { status: "running" });
      if (signal.aborted) throw new ApiError(499, "CANCELED", "\uC911\uB2E8\uB428");
      const response = await this.host.generate(state.user, generate, signal);
      if (signal.aborted) throw new ApiError(499, "CANCELED", "\uC911\uB2E8\uB428");
      const choice = response?.choices?.[0];
      const message = choice?.message;
      let content = message?.content ?? choice?.text;
      if (job.toolName && message?.tool_calls?.length === 1 && message.tool_calls[0].function?.name === job.toolName) {
        content = JSON.parse(message.tool_calls[0].function.arguments).content;
      }
      requireValue(typeof content === "string" && content.length > 0, "\uBAA8\uB378\uC5D0\uC11C \uC800\uC7A5\uD560 \uB2F5\uBCC0\uC744 \uBC1B\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      const result = { content, reasoning: message?.reasoning_content ?? message?.reasoning ?? "", response };
      await this.update(state, job, { status: "completed", result });
      await this.host.coordinator.withChatWrite(state.user, () => serialized(state.file, async () => {
        if (signal.aborted || job.status === "canceled" || job.status === "interrupted") return;
        const file = this.host.coordinator.chatPath(state.user, job.target);
        const chat = await this.readChat(file);
        if (chat.some((m) => m.extra?.damsoJobId === job.id)) {
          job.status = "saved";
          job.savedRevision = this.host.coordinator.fileRevision(file);
          await this.persist(state);
          return;
        }
        if (this.host.coordinator.fileRevision(file) !== job.expectedRevision) {
          job.status = "conflict";
          await this.persist(state);
          return;
        }
        job.status = "committing";
        await this.persist(state);
        const reply = {
          name: job.target.ch_name,
          is_user: false,
          is_system: false,
          send_date: (/* @__PURE__ */ new Date()).toISOString(),
          mes: content,
          extra: { damsoJobId: job.id, reasoning: result.reasoning, api: "openai", model: generate.model },
          swipe_id: 0,
          swipes: [content]
        };
        if (job.target.type === "regenerate" && chat.at(-1)?.is_user === false && !chat.at(-1)?.is_system) chat[chat.length - 1] = { ...chat.at(-1), ...reply };
        else chat.push(reply);
        await this.host.save(state.user, file, chat, job.target.avatar_url);
        job.status = "saved";
        job.savedRevision = this.host.coordinator.fileRevision(file);
        await this.persist(state);
      }));
    } catch (error) {
      if (TERMINAL.has(job.status)) return;
      await this.update(state, job, { status: signal.aborted ? this.stopping ? "interrupted" : "canceled" : "failed", error: { code: error.code || "GENERATION_FAILED", message: "\uC0DD\uC131 \uB610\uB294 \uC800\uC7A5\uC744 \uC644\uB8CC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.", retryable: ![400, 401, 403, 404, 413, 422, 499].includes(error.status) } });
    }
  }
  async cancel(user, id) {
    const state = await this.state(user);
    return serialized(state.file, async () => {
      const job = state.doc.jobs.find((j) => j.id === id);
      if (!job) throw new ApiError(404, "NOT_FOUND", "\uC791\uC5C5\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
      if (TERMINAL.has(job.status)) return structuredClone(job);
      job.status = "canceled";
      this.active.get(id)?.controller.abort();
      await this.persist(state);
      return structuredClone(job);
    });
  }
  async stop() {
    this.stopping = true;
    for (const { controller } of this.active.values()) controller.abort();
    await Promise.allSettled([...this.active.values()].map((a) => a.promise));
  }
};

// server/host-adapter/index.mjs
import { EventEmitter } from "node:events";
import path6 from "node:path";
import fs6 from "node:fs/promises";
import { pathToFileURL } from "node:url";
async function createHostAdapter(root = process.cwd()) {
  const pkg = JSON.parse(await fs6.readFile(path6.join(root, "package.json"), "utf8"));
  if (pkg.name !== "sillytavern" || !HOST_VERSIONS.includes(pkg.version)) throw new Error("Unsupported SillyTavern version");
  const module = (file) => import(pathToFileURL(path6.join(root, "src", file)).href);
  const [chats, generation, coordinator, tokenizers, settings, extensions, characters, backups] = await Promise.all([
    module("endpoints/chats.js"),
    module("endpoints/backends/chat-completions.js"),
    module("damso-chat-coordinator.mjs"),
    module("endpoints/tokenizers.js"),
    module("endpoints/settings.js"),
    module("endpoints/extensions.js"),
    module("endpoints/characters.js"),
    module("endpoints/backups.js")
  ]);
  const routers = { chats, tokenizers, settings, extensions, characters, backups };
  return {
    root,
    version: pkg.version,
    coordinator,
    supported: coordinator.coordinationInstalled() && typeof generation.damsoGenerate === "function",
    async request(kind, route, user, body = {}, query = {}, method = "POST") {
      const router = routers[kind]?.router;
      if (!router) throw new ApiError(501, "UNSUPPORTED", "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uD638\uC2A4\uD2B8 \uAE30\uB2A5\uC785\uB2C8\uB2E4.");
      const layer = router.stack.find((layer2) => layer2.route?.path === route && layer2.route.methods[method.toLowerCase()]);
      if (!layer) throw new ApiError(501, "UNSUPPORTED", "\uD638\uC2A4\uD2B8 \uACBD\uB85C\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
      return invokeHandlers(layer.route.stack.map((s) => s.handle), user, body, query);
    },
    async generate(user, body, signal) {
      const result = await invokeHandlers([generation.damsoGenerate], user, { ...structuredClone(body), stream: false }, {}, signal, true);
      if (result?.error) throw new ApiError(502, "GENERATION_FAILED", "\uBAA8\uB378 \uC694\uCCAD\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.");
      return result;
    },
    async save(user, file, chat, avatar) {
      await chats.trySaveChat(chat, file, false, user.profile.handle, avatar.replace(".png", ""), user.directories.backups);
    }
  };
}
function invokeHandlers(handlers, user, body, query = {}, signal, background = false) {
  return new Promise((resolve, reject) => {
    const socket = new EventEmitter();
    const req = Object.assign(new EventEmitter(), { user, body: structuredClone(body), query, headers: {}, socket, damsoBackground: background });
    const res = Object.assign(new EventEmitter(), {
      statusCode: 200,
      headersSent: false,
      writableEnded: false,
      status(code) {
        this.statusCode = code;
        return this;
      },
      setHeader() {
        return this;
      },
      header() {
        return this;
      },
      set() {
        return this;
      },
      send(data) {
        this.headersSent = true;
        this.writableEnded = true;
        signal?.removeEventListener("abort", abort);
        if (this.statusCode >= 400) reject(new ApiError(this.statusCode, "HOST_ERROR", "\uD638\uC2A4\uD2B8 \uC694\uCCAD\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4."));
        else resolve(data);
        this.emit("finish");
        return this;
      },
      json(data) {
        return this.send(data);
      },
      sendStatus(code) {
        return this.status(code).send(null);
      },
      end(data) {
        return this.send(data);
      }
    });
    const abort = () => {
      socket.emit("close");
      reject(new ApiError(499, "CANCELED", "\uC0DD\uC131\uC744 \uC911\uB2E8\uD588\uC2B5\uB2C8\uB2E4."));
    };
    if (signal?.aborted) return abort();
    signal?.addEventListener("abort", abort, { once: true });
    let index = 0;
    const next = (error) => {
      if (error) return reject(error);
      const handler = handlers[index++];
      if (!handler) return reject(new Error("Host route did not respond"));
      try {
        Promise.resolve(handler(req, res, next)).catch(reject);
      } catch (error2) {
        reject(error2);
      }
    };
    next();
  });
}

// server/index.mjs
var info = { id: "st-ko-tools", name: "\uB2F4\uC18C \uB3C4\uAD6C\uD568", description: "\uD55C\uAD6D\uC5B4 \uD3B8\uC758 \uAE30\uB2A5\uACFC \uC0AC\uC6A9\uC790\uBCC4 \uC800\uC7A5\xB7\uC0DD\uC131 \uC11C\uBE44\uC2A4" };
var jobs;
async function init(router, options = {}) {
  const host = options.host || await createHostAdapter();
  jobs = new JobManager(host);
  const backups = new Backups();
  const cache = new FileCache();
  const route = (method, endpoint, fn, raw = false) => router[method](`/v1${endpoint}`, async (req, res) => {
    try {
      await userStore(req.user);
      res.setHeader("Cache-Control", "no-store");
      const data = await fn(req, res);
      if (!res.headersSent) res.json(raw ? data : { ok: true, data });
    } catch (error) {
      if (!res.headersSent) res.status(error.status || 500).json({ ok: false, error: { code: error.code || "INTERNAL_ERROR", message: error instanceof ApiError ? error.message : "\uC694\uCCAD\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.", retryable: !error.status || error.status >= 500, ...error.details } });
    }
  });
  route("get", "/status", async (req) => ({
    protocolVersion: PROTOCOL_VERSION,
    packageVersion: PACKAGE_VERSION,
    host: { supported: host.supported, version: host.version },
    storage: { ready: Boolean(await userStore(req.user)) },
    capabilities: {
      promptLibrary: true,
      presetBackups: true,
      chatLists: true,
      settingsBootstrap: true,
      extensionBundle: true,
      lazyThemes: true,
      tokenizerBulk: true,
      backgroundJobs: host.supported,
      backgroundJobSources: host.supported ? ["openai", "custom"] : [],
      backgroundJobTypes: ["normal", "regenerate"],
      completeResponseTool: true,
      n: 1
    }
  }));
  route("get", "/config", async (req) => ({ ...await getConfig(req.user), uiEnabled: await uiEnabled(req.user) }));
  route("put", "/config", (req) => changeDocument(req.user, "config", CONFIG_DEFAULTS, req.body.expectedRevision, (current) => {
    for (const key of Object.keys(CONFIG_DEFAULTS)) {
      if (req.body[key] === void 0) continue;
      requireValue(typeof req.body[key] === typeof CONFIG_DEFAULTS[key]);
      current[key] = req.body[key];
    }
    requireValue(Number.isSafeInteger(current.backupKeepCount) && current.backupKeepCount >= 1 && current.backupKeepCount <= 1e5);
    current.progressiveChatLoadingEnabled = false;
    if (!current.settingsAccelerationEnabled) current.lazyThemeLoadingEnabled = false;
    cache.clear(req.user);
    return current;
  }));
  route("get", "/prompt-library", (req) => getLibrary(req.user));
  route("put", "/prompt-library", (req) => putLibrary(req.user, req.body));
  route("post", "/preset-backups", (req) => backups.create(req.user, req.body));
  route("post", "/preset-backups/list", (req) => backups.list(req.user));
  route("post", "/preset-backups/get", (req) => backups.get(req.user, req.body.fileName));
  route("post", "/preset-backups/rename", (req) => {
    requireValue(typeof req.body.showName === "string" && req.body.showName.trim().length > 0 && req.body.showName.length < 300);
    return backups.mutate(req.user, req.body.fileName, { showName: req.body.showName, name: req.body.showName }, req.body.expectedRevision);
  });
  route("post", "/preset-backups/note", (req) => {
    requireValue(typeof req.body.note === "string" && req.body.note.length <= 1e4);
    return backups.mutate(req.user, req.body.fileName, { note: req.body.note }, req.body.expectedRevision);
  });
  route("post", "/preset-backups/delete", (req) => backups.mutate(req.user, req.body.fileName, "delete", req.body.expectedRevision));
  route("post", "/preset-backups/prune", async (req) => serialized(await backups.directory(req.user), async () => {
    const config = await readDocument(req.user, "config", CONFIG_DEFAULTS);
    requireValue(config.backupAutoCleanupEnabled && req.body.expectedRevision === config.revision, "\uC815\uB9AC \uC124\uC815\uC744 \uB2E4\uC2DC \uD655\uC778\uD574 \uC8FC\uC138\uC694.");
    await backups.prune(req.user, config.backupKeepCount);
    return backups.list(req.user);
  }));
  const nativeCached = (kind, endpoint, dirs) => (req) => cache.get(req.user, kind + endpoint + JSON.stringify(req.body || {}), dirs(req.user), () => host.request(kind, endpoint, req.user, req.body));
  const chatDirs = (u) => [u.directories.chats, u.directories.groupChats, u.directories.groups, u.directories.characters];
  route("post", "/chats/search", nativeCached("chats", "/search", chatDirs), true);
  route("post", "/chats/recent", nativeCached("chats", "/recent", chatDirs), true);
  route("get", "/chats/recent", nativeCached("chats", "/recent", chatDirs), true);
  route("post", "/chat-backups/list", nativeCached("backups", "/chat/get", (u) => [u.directories.backups]), true);
  route("post", "/characters/list", nativeCached("characters", "/all", (u) => [u.directories.characters]), true);
  route("post", "/chats/get", (req) => host.coordinator.withChatWrite(req.user, async () => {
    const file = host.coordinator.chatPath(req.user, req.body);
    return { chat: await jobs.readChat(file), revision: host.coordinator.fileRevision(file) };
  }));
  route("post", "/bootstrap/settings", async (req) => {
    const dirs = ["root", "novelAI_Settings", "openAI_Settings", "textGen_Settings", "koboldAI_Settings", "worlds", "themes", "movingUI", "quickreplies", "instruct", "context", "sysprompt", "reasoning"];
    const data = await cache.get(req.user, "settings", dirs.map((k) => k === "root" ? path7.join(req.user.directories.root, "settings.json") : req.user.directories[k]).filter(Boolean), () => host.request("settings", "/get", req.user));
    const config = await readDocument(req.user, "config", CONFIG_DEFAULTS);
    if (config.lazyThemeLoadingEnabled && config.settingsAccelerationEnabled) {
      const settings = JSON.parse(data.settings);
      const active = settings.power_user?.theme;
      data.themes = data.themes.map((theme) => theme.name === active ? theme : { name: theme.name, damsoLazy: true });
    }
    return data;
  }, true);
  route("post", "/themes/get", async (req) => {
    requireValue(typeof req.body.name === "string" && !/[/\\\0]/.test(req.body.name));
    return JSON.parse(await fs7.readFile(await safeFile(req.user.directories.themes, `${req.body.name}.json`), "utf8"));
  });
  route("get", "/extensions/bundle", async (req) => {
    const entries = await host.request("extensions", "/discover", req.user, {}, {}, "GET");
    const manifests = {};
    for (const entry of entries) {
      const root = entry.type === "local" ? req.user.directories.extensions : path7.join(host.root, "public/scripts/extensions", entry.type === "global" ? "third-party" : "");
      const name = entry.type === "system" ? entry.name : entry.name.replace(/^third-party\//, "");
      manifests[entry.name] = JSON.parse(await fs7.readFile(await safeFile(root, `${name}/manifest.json`), "utf8"));
    }
    return { entries, manifests };
  });
  route("post", "/tokenizers/bulk-count", async (req) => {
    const items = req.body.items;
    requireValue(Array.isArray(items) && items.length <= 512);
    const counts = [];
    for (const item of items) {
      requireValue(typeof item.id === "string" && typeof item.model === "string" && Array.isArray(item.messages));
      const result = await host.request("tokenizers", "/openai/count", req.user, item.messages, { model: item.model });
      requireValue(Number.isFinite(result?.token_count));
      counts.push({ id: item.id, count: result.token_count });
    }
    return { counts };
  });
  route("post", "/jobs", (req) => {
    requireValue(host.supported, "\uD638\uC2A4\uD2B8 \uC5F0\uACB0\uC744 \uBA3C\uC800 \uC124\uCE58\uD574 \uC8FC\uC138\uC694.");
    return jobs.submit(req.user, req.body);
  });
  route("get", "/jobs", (req) => jobs.list(req.user));
  route("get", "/jobs/:id", (req) => jobs.get(req.user, req.params.id));
  route("post", "/jobs/:id/cancel", (req) => jobs.cancel(req.user, req.params.id));
  route("get", "/assets/early-bridge.js", async (req, res) => {
    const file = path7.join(path7.dirname(fileURLToPath(import.meta.url)), "early-bridge.js");
    res.type("application/javascript").send(await fs7.readFile(file, "utf8"));
  });
  return { host, jobs, backups, cache, apiRoot: API_ROOT };
}
async function exit() {
  await jobs?.stop();
}
export {
  exit,
  info,
  init
};
